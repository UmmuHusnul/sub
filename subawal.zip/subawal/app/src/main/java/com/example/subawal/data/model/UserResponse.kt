package com.example.subawal.data.model

data class UserResponse(
    val items: ArrayList<User>
)
